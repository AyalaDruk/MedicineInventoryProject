package medicine;

public abstract class Medicine {
    //Attributes
    private String medicineName;
    private String companyName;
    private String companyEmail;
    private double price;
    private int quantity;
    private String expirationYear;
    //type enum
    private medType type;

    private final String strudel = "@";
    private final String dot = ".";


    public enum medType {
        PILLS,
        SYRUP,
        INHALER
    }

    //constructors


    public Medicine(String medicineName, String companyName, String companyEmail, double price, int quantity, String expirationYear, medType type) {
        setMedicineName(medicineName);
        setCompanyName(companyName);
        setCompanyEmail(companyEmail);
        setPrice(price);
        setQuantity(quantity);
        setExpirationYear(expirationYear);
        setType(type);
    }

    public Medicine() {
    }

    //setters
    public void setMedicineName(String medicineName) {
        this.medicineName = medicineName.toUpperCase();
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public void setCompanyEmail(String companyEmail) {
        boolean isEmailOk = true;
        //check if email empty or null
        if (companyEmail.isEmpty() || companyEmail == null) {
            System.out.println("Error: Email is empty or null");
            isEmailOk = false;
        }
        //check if email contain @
        if (!companyEmail.contains((strudel))) {
            System.out.println("Error: mail does not contain @");
            isEmailOk = false;

        }
         //check if email start or end with @
        if (companyEmail.startsWith(strudel) || companyEmail.endsWith(strudel)) {
            System.out.println("Error:@ is the first character or the last character");
            isEmailOk = false;
        }
        //check if email contains . in domain
        if (!companyEmail.substring(companyEmail.indexOf(strudel)).contains(dot)) {
            System.out.println("Error: no . character in the domain ");
            isEmailOk = false;

        }
        if (isEmailOk)
            this.companyEmail = companyEmail;
        else
            this.companyEmail = "incorrect_mail@gmail.com";

    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public void setExpirationYear(String expirationYear) {
        this.expirationYear = expirationYear;
    }

    private void setType(medType type) {
        this.type = type;
    }

//    public void setType(String type) {
//
//
//        if (type.equalsIgnoreCase("Syrup") || type.equalsIgnoreCase("Pills") || type.equalsIgnoreCase("Inhaler")) {
//            this.type = type;
//        } else System.out.println("the type of medicine is incorrect,please try again");
//
//    }

    //getters


    public String getMedicineName() {
        return medicineName;
    }

    public String getCompanyName() {
        return companyName;
    }

    public String getCompanyEmail() {
        return companyEmail;
    }

    public double getPrice() {
        return price;
    }

    public int getQuantity() {
        return quantity;
    }

    public String getExpirationYear() {
        return expirationYear;
    }

    public medType getType() {
        return type;
    }

    //    public String getType() {
//        return type;
//    }

    //Methods
    public void printMedicine() {
        System.out.println("Medicine name: " + getMedicineName() + " Company name: " + getMedicineName() + " Company mail: " + getCompanyEmail() + " price= " + getPrice()
                + " Quantity: " + getQuantity() + " ExpirationYear: " + getExpirationYear() + " Medicine type = " + getType());
    }


    //Abstract method
    //calculation the total inventory for each type
    public abstract double totalInventory();

    //Method
    // check if medicine in stock
    public boolean inStuck() {
        if (getQuantity() > 0)
            return true;
        else
            return false;
    }
}

