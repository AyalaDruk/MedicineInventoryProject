package medicine;

import java.util.ArrayList;

public class mainMedicine {
    public static void main(String[] args) {
        //create a new arraylist of medicine
        ArrayList<Medicine> medInventory = new ArrayList<Medicine>();
        // using add() to add and create medicine to arraylist
        medInventory.add(new Pills("Acamol", "Teva", "info@teva.il", 28.90, 120, "2027", Medicine.medType.PILLS, 20));
        medInventory.add(new Pills("Omepradex", "Dexcel pharma", "info@dexcel.il", 32.50, 200, "2025", Medicine.medType.PILLS, 25));
        medInventory.add(new Pills("Folex", "Rafa", "info@rafa.il", 19.90, 175, "2029", Medicine.medType.PILLS, 32));
        medInventory.add(new Syrup("Akamoli", "Teva", "info@teva.il", 17.30, 80, "2032", Medicine.medType.SYRUP, 200.2));
        medInventory.add(new Syrup("Nurofen for children", "RB", "consumer.relations@rb.com", 27.70, 173, "2026", Medicine.medType.SYRUP, 100.5));
        medInventory.add(new Syrup("Mucolit", "Sanofi", "info.israel@sanofi.com", 30.70, 120, "2028", Medicine.medType.SYRUP, 200.4));
        medInventory.add(new Inhaler("Ventolin", "GSK", "us.customer-relation@gsk.com", 142.40, 230, "2032", Medicine.medType.INHALER, 200));
        medInventory.add(new Inhaler("Symbicorn", "AstraZeneca", "IR@astrazeneca.com", 299.90, 172, "2028", Medicine.medType.INHALER, 120));
        medInventory.add(new Inhaler("Flixotide", "GSK", "us.customer-relation@gsk.com", 199.20, 150, "2034", Medicine.medType.INHALER, 120));
// print all medicine in stock
        for (Medicine inventory : medInventory) {
            inventory.printMedicine();
        }

        double numOfPills = 0;
        double numOfSyrus = 0;
        double numOfInhaler = 0;

//print medicine  total inventory for each type
        for (Medicine med : medInventory) {
            if (med.getType() == Medicine.medType.PILLS)
                numOfPills += med.totalInventory();
            if (med.getType() == Medicine.medType.SYRUP)
                numOfSyrus += med.totalInventory();
            if (med.getType() == Medicine.medType.INHALER)
                numOfInhaler += med.totalInventory();
        }
        System.out.println("total of pills:   " + numOfPills + "  total of syrup :" + numOfSyrus + " total of inhaler: " + numOfInhaler);

    }


}



