package medicine;

public class Pills extends Medicine {

    //Attribute
    private int numOfPillsInBox;

//constructor

    public Pills() {
    }

    public Pills(String medicineName, String companyName, String companyEmail, double price, int quantity, String expirationYear, medType type, int numOfPillsInBox) {
        super(medicineName, companyName, companyEmail, price, quantity, expirationYear, type);
        setNumOfPillsInBox(numOfPillsInBox);
    }

    //setter
    public void setNumOfPillsInBox(int numOfPillsInBox) {
        this.numOfPillsInBox = numOfPillsInBox;
    }
    //getter

    public int getNumOfPillsInBox() {
        return numOfPillsInBox;
    }

    //Methods
    public void printMedicine() {
        super.printMedicine();
        System.out.println("numOfPillsInBox: " + getNumOfPillsInBox());
    }

    @Override
    public double totalInventory() {
        double totalPills = getNumOfPillsInBox() * getQuantity();
        return totalPills;
    }
}
