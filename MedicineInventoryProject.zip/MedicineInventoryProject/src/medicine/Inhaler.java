package medicine;

public class Inhaler extends Medicine {
    //attribute
    private double amountOfClick;

    //constructor


    public Inhaler() {
    }

    public Inhaler(String medicineName, String companyName, String companyEmail, double price, int quantity, String expirationYear, medType type, double amountOfClick) {
        super(medicineName, companyName, companyEmail, price, quantity, expirationYear, type);
        setAmountOfClick(amountOfClick);
    }

    //getter
    public double getAmountOfClick() {
        return amountOfClick;
    }

    //setter
    public void setAmountOfClick(double amountOfClick) {
        this.amountOfClick = amountOfClick;
    }

    //methods
    public void printMedicine() {
        super.printMedicine();
        System.out.println("amountOfClick: " + getAmountOfClick());
    }

    @Override
    public double totalInventory() {
        double totalInhaler = getAmountOfClick() * getQuantity();
        return totalInhaler;

    }
}
