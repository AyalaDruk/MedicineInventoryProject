package medicine;

public class Syrup extends Medicine {
    //Attribute
    private double bottleContent;

    //constructor


    public Syrup() {
    }



    public Syrup(String medicineName, String companyName, String companyEmail, double price, int quantity, String expirationYear, medType type, double bottleContent) {
        super(medicineName, companyName, companyEmail, price, quantity, expirationYear, type);
        setBottleContent(bottleContent);
    }

    //Setter
    public void setBottleContent(double bottleContent) {
        this.bottleContent = bottleContent;
    }

    //Getter

    public double getBottleContent() {
        return bottleContent;
    }

    //methods
    public void printMedicine() {
        super.printMedicine();
        System.out.println("bottleContent= "+ getBottleContent());
    }

    @Override
    public double totalInventory() {
        double totalSyrup= getBottleContent()*getQuantity();
        return totalSyrup;
    }
}
